<?php

return array(
	'version' => '0.9.3',
	'browsercache.configuration_sealed' => false,
	'cdn.configuration_sealed' => false,
	'cloudflare.configuration_sealed' => false,
	'common.install' => 1392382191,
	'common.visible_by_master_only' => true,
	'dbcache.configuration_sealed' => false,
	'minify.configuration_sealed' => false,
	'objectcache.configuration_sealed' => false,
	'pgcache.configuration_sealed' => false,
	'previewmode.enabled' => false,
	'varnish.configuration_sealed' => false,
	'fragmentcache.configuration_sealed' => false,
	'newrelic.configuration_sealed' => false,
	'extensions.configuration_sealed' => array(
	),
	'notes.minify_error' => false,
	'minify.error.last' => '',
	'minify.error.notification' => '',
	'minify.error.notification.last' => 0,
	'minify.error.file' => '',
	'notes.remove_w3tc' => false,
);